package com.atoms.exception;

public class CityNameEmpty extends Exception {

	public CityNameEmpty() {
		super();
	}

	public CityNameEmpty(String message) {
		super(message);
	}
}
