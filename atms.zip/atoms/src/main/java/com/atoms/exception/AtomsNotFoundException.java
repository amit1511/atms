package com.atoms.exception;

public class AtomsNotFoundException extends Exception {

	public AtomsNotFoundException() {
		super();
	}

	public AtomsNotFoundException(String message) {
		super(message);
	}
}
