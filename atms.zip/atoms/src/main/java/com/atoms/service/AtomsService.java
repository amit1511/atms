package com.atoms.service;

import java.util.List;

import com.atoms.exception.AtomsNotFoundException;
import com.atoms.model.Atoms;

public interface AtomsService {

	public List<Atoms> getAtomsListByAPI();

	public List<Atoms> getAtoms() throws AtomsNotFoundException;

	public List<Atoms> getAtomsByCity(String city) throws AtomsNotFoundException;
}
