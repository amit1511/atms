package com.atoms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.atoms.exception.AtomsNotFoundException;
import com.atoms.model.Atoms;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class AtomsServiceImpl implements AtomsService {

	@Autowired
	private RestTemplate restTemplate;

	public List<Atoms> getAtomsListByAPI() {

		String mapper = restTemplate.getForObject("https://www.ing.nl/api/locator/atms/", String.class);
		ObjectMapper objectMapper = new ObjectMapper();
		List<Atoms> atoms = new ArrayList<Atoms>();

		try {
			atoms = objectMapper.readValue(mapper.substring(6), new TypeReference<List<Atoms>>() {
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return atoms;
	}

	public List<Atoms> getAtoms() throws AtomsNotFoundException {
		List<Atoms> atoms = getAtomsListByAPI();

		if(atoms.size() <=0) {
			throw new AtomsNotFoundException("Atoms are empty");
		}
		return atoms;
	}

	public List<Atoms> getAtomsByCity(String city) throws AtomsNotFoundException {

		List<Atoms> atoms = getAtomsListByAPI();

		atoms = atoms.stream().filter(atom -> atom.getAddress().getCity().equalsIgnoreCase(city))
				.collect(Collectors.toList());

		if (atoms.size() <= 0) {
			throw new AtomsNotFoundException("Atoms not found for crossponding city : " + city);
		}
		return atoms;
	}
}
