package com.atoms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class AtomsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtomsApplication.class, args);
	}

	// Returning RestTemplate Instance for calling external API 
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
}
