package com.atoms.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.atoms.exception.AtomsNotFoundException;
import com.atoms.exception.CityNameEmpty;
import com.atoms.model.Atoms;
import com.atoms.service.AtomsService;

@RestController
public class AtomsController {

	@Autowired
	AtomsService atomsService;

	// Get all atms
	@GetMapping("atms")
	public List<Atoms> getAtoms() throws AtomsNotFoundException {

		List<Atoms> atoms = atomsService.getAtoms();
		return atoms;
	}

	// Get atms based on city
	@GetMapping("atms/city")
	public List<Atoms> getAtomsByCity(@RequestParam(name = "city") String city)
			throws AtomsNotFoundException, CityNameEmpty {

		if (city.isBlank()) {
			throw new CityNameEmpty("City is mandatory for searching based on city");
		}
		List<Atoms> atoms = atomsService.getAtomsByCity(city);
		return atoms;
	}

}
