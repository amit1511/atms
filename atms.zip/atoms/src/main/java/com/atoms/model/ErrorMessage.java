package com.atoms.model;

import org.springframework.http.HttpStatus;

public class ErrorMessage {

	private HttpStatus status;
	private String businessMessage;

	public HttpStatus getStatusCode() {
		return status;
	}

	public void setStatusCode(HttpStatus status) {
		this.status = status;
	}

	public String getBusinessMessage() {
		return businessMessage;
	}

	public void setBusinessMessage(String businessMessage) {
		this.businessMessage = businessMessage;
	}

	public ErrorMessage() {
		super();
	}

	public ErrorMessage(HttpStatus status, String businessMessage) {
		super();
		this.status = status;
		this.businessMessage = businessMessage;
	}

}
