package com.atoms.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.atoms.exception.AtomsNotFoundException;

@SpringBootTest
public class AtomsServiceTest {

	@Autowired
	private AtomsService atomsService;

	@Test
	public void cityNotFound() {

		String city = "Ranchi";
		try {
			atomsService.getAtomsByCity(city);
		} catch (AtomsNotFoundException ex) {
			assertEquals(ex.getMessage(), "Atoms not found for crossponding city : " + city);
		}

	}
}
